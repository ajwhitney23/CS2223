
class player
{
public:
    player();
    virtual ~player();
    int makeMove(board *b);
};
