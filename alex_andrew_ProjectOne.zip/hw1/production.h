
class production
{
private:
    int turn;

public:
    production();
    virtual ~production();
    int gameStart();
};