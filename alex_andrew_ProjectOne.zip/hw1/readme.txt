---PROGRAM MUST BE RUN ON LINUX/MAC---

---DIRECTIONS FOR USE---

---COMPILE INSTRUCTIONS---
open terminal in the directory this readme is located,
which at a minimum must contain:

Run 'make' to build the application
Run 'make clean' to delete the executable before rebuilding

---RUNNING JUST THE PROGRAM---
open terminal in the directory in which the 'dt' file is located and
run the following command.

Usage: ./nim

Follow the text instructions to play the game
