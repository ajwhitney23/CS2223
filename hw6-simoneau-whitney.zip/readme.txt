to run:

> make
> ./queens <partNum> <boardSize>

part 1 is testing isLegalPosition
    enter board by following prompt, the number inputted is the column for the given row

part 2 is testing nextLegalPosition
    enter board by following prompt, legal positions will be found

part 3 is finding the first solution for every board size from 4-boardSize entered

part 4 is finding all solutions for a given boardSize